package collectionsdemo;
	
	import java.util.*;
	public class Collections {

		public static void main(String[] args) {
			
			System.out.println("ArrayList");
			ArrayList<String> city=new ArrayList<String>();   
		      city.add("Hyderabad");
		      city.add("Mumbai");    	   
		      System.out.println(city);  
		      
			
		      System.out.println("\n");
		      System.out.println("Vector");
		      Vector<Integer> vec = new Vector<Integer>();
		      vec.addElement(5); 
		      vec.addElement(15); 
		      System.out.println(vec);
			
			
		      System.out.println("\n");
		      System.out.println("LinkedList");
		      LinkedList<String> names=new LinkedList<String>();  
		      names.add("Vishwa");  
		      names.add("Vishnu");  	      
		      Iterator<String> itr=names.iterator();  
		      while(itr.hasNext()){  
		       System.out.println(itr.next());  
		       
		       
		       System.out.println("\n");
		       System.out.println("HashSet");
		       HashSet<Integer> set=new HashSet<Integer>();  
		       set.add(251);  
		       set.add(252);  
		       set.add(253);
		       set.add(254);
		       System.out.println(set);
		       
		      
		       System.out.println("\n");
		       System.out.println("LinkedHashSet");
		       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
		       set2.add(21);  
		       set2.add(22);  
		       set2.add(23);
		       set2.add(24);	       
		       System.out.println(set2);
		      	} 
		      }  
		}

