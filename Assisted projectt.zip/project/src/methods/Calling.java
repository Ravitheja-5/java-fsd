package methods;

public class Calling {
	public int multipynumbers(int a,int b) {
			int z=a*b;
			return z;
		}

		public static void main(String[] args) {

			Calling b=new Calling();
			int ans= b.multipynumbers(5,4);
			System.out.println("Multipilcation is :"+ans);
			}

		public class callMethod {

		int val=150;

		int operation(int val) {
			val =val*10/100;
			return(val);
		}

		public  void main(String args[]) {
			callMethod d = new callMethod();
			System.out.println("Before operation value of data is "+d.val);
			d.operation(100);
			System.out.println("After operation value of data is "+d.val);
			}
		}

		public class overloadMethod {
			
		public void area(int b,int h)
		    {
		         System.out.println("Area of Triangle : "+(0.5*b*h));
		    }
		    public void area(int r) 
		    {
		         System.out.println("Area of Circle : "+(3.14*r*r));
		    }

		    public void main(String args[])
		   {

		overloadMethod ob=new overloadMethod();
		       ob.area(10,12);
		       ob.area(5);  
		   }
		}



}
