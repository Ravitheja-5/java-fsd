package regulardemo;

import java.util.regex.*;

	public class expressions {

		public static void main(String[] args) {

		String pattern = "[A-Z][a-z]+";
		String check = "Electrical Engineer";
		Pattern p = Pattern.compile(pattern);
		Matcher c = p.matcher(check);
		
		while (c.find())
	      	System.out.println( check.substring( c.start(), c.end() ) );
		}
	}


